<?php session_start(); ?>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cooperativa | Etec 032</title>
    <!--ICON-->
    <link rel="shortcut icon" type="imagex/png" href="../img/logo ico.ico">
    <!--FONTES-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Acme&family=Cabin:ital,wght@0,400..700;1,400..700&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap"
        rel="stylesheet">
    <!--CSS Do BootStrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--CSS externo-->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/lista_fun.css">
    <!--CSS BOX ICONS-->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <style>
        #footer {
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            padding-top: 20px;
            background-color: #158451;
            color: #ffffff;
            font-size: 18px;
        }
    </style>
</head>

<body>
    <!--navbar-->
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#" onclick="location.reload();">
            <img src="../img/widelogo.png" width="180" height="60" class="d-inline-block align-top" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
            aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Alterna navegação">
            <span class="navbar-toggler-icon"></span>
        </button>

        <ul class="navbar-nav" style="margin-left: 20px;">
            <div class="collapse navbar-collapse nav-item justify-content-end">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php">Todos Produtos</a>
                    </li>
                </ul>
            </div>
        </ul>

        <div class="collapse navbar-collapse nav-item justify-content-end" id="conteudoNavbarSuportado">
            <!--pesquisar btn-->
            <form class="form-inline my-2 my-lg-0" action="pesquisa_produtos.php" method="GET">
                <input class="form-control mr-sm-2" type="search" name="q" placeholder="Pesquisar" aria-label="Pesquisar">
                <button class="btn btn-outline my-2 my-sm-0" type="submit"><i class='bx bx-search'></i></button>
            </form>
            <!--itens-->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="../front-end/carrinho.php"><i class='bx bx-cart' data-toggle="popover" data-html="true"
                            data-placement="bottom"
                            data-content="Ver Carrinho!"></i></a>
                </li>
                <li class="nav-item">
                    <div class="dropdown">
                        <a class="nav-link" href="" id="dropdown-perfil" data-toggle="dropdown"><i class='bx bx-user-circle'></i></a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-perfil">
                            <a class="dropdown-item" href="../front-end/perfilcliente.php">Perfil</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-danger" href="#" data-toggle='modal' data-target='#modalsair'>Sair</a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </nav>


    <!--header-->
    <section id="produtos">
        <?php
        $paginaAnterior = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'http://localhost/Site%20Final%20TCC/back-end/adicionar_ao_carrinho.php';

        if ($paginaAnterior == "http://localhost/Site%20Final%20TCC/back-end/adicionar_ao_carrinho.php") {
            echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
                    Ver <a href='../front-end/carrinho.php' class='alert-link'>CARRINHO</a>. Clique nele, se quiser ver.
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                        <span aria-hidden='true'>&times;</span>
                    </button>
                </div>";
        }
        ?>
        <H1 style="color: #fff;"><span class="trace">|</span>Todos os Produtos</H1><br>
        <div class="produtos-box">
            <?php


            ini_set('default_charset', 'UTF-8');
            require '../conexao.php';

            mysqli_set_charset($con, 'utf8');

            if ($con) {
                $sql = "select pro_cod, pro_nome, pro_qtde, pro_preco, pro_dt_validade, pro_foto from Produtos order by pro_nome";
                $result = mysqli_query($con, $sql);
                mysqli_close($con);

                while ($dados = mysqli_fetch_assoc($result)) {
                    $pro_cod = $dados['pro_cod'];
                    $pro_nome = $dados['pro_nome'];
                    $pro_qtde = $dados['pro_qtde'];
                    $pro_preco = $dados['pro_preco'];
                    $pro_dt_validade = $dados['pro_dt_validade'];
                    $pro_foto = $dados['pro_foto'];

                    if ($pro_qtde > 0)
                    echo "
                            <div class='individual-box'>
                                <div class='img-container'>
                                    <img src='$pro_foto'>
                                </div>
                                <h5>$pro_nome</h5>
                                <div class='validade'>
                                    <i class='bx bx-calendar-exclamation'></i>Val
                                    $pro_dt_validade <br>
                                    Qtde. disponível: $pro_qtde
                                </div>
                                <div class='preco'>
                                    <span>R$$pro_preco</span>
                                    <a href='' type='button' class='btn btn-primary btn-cart' data-toggle='modal' data-target='#modalcarrinho' onclick='setProCode(\"$pro_cod\", \"$pro_qtde\")'><i
                                        class='bx bx-cart-add'></i></a>
                                </div>
                            </div>";
                }
            }
            ?>
        </div>
        <br>
    </section>

    <!--FOOTER-->
    <footer id="footer">
        <div class="footer-content">
            <div class="footer-content-quicklinks">
                <h5>Acesso Rápido</h5>
                <ul>
                    <li class="quicklinks"><a href="index.html">Início</a></li>
                    <li class="quicklinks"><a href="index.html">Sobre</a></li>
                    <li class="quicklinks"><a href="#produtos">Produtos</a></li>
                </ul>
            </div>
            <div class="footer-content-contact">
                <h5>Contatos</h5>
                <p>(18) 3222-8466</p>
                <p>(18) 98196-1025</p>
                <p>etecppagricola@gmail.com</p>
                <p>SP-270, 561 - Pres. Prudente - SP</p>
            </div>
            <div class="footer-content-socials">
                <h5>Redes Sociais</h5>
                <a href="https://www.instagram.com/colegioagricolaprudenteoficial/"><i class='bx bxl-instagram'></i>
                    Instagram</a><br>
                <a href="https://www.facebook.com/colegioagricolaprudenteoficial/?locale=pt_BR"><i
                        class='bx bxl-facebook'></i> Facebook</a> <br>
                <a href="https://web.whatsapp.com/send?phone=5518981961025"><i class='bx bxl-whatsapp'></i> WhatsApp</a>
            </div>
        </div>
        <br>
        <p>&copy; 2024
    </footer>

    <!--MODAL - Carrinho-->
    <div class="modal fade" id="modalcarrinho" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Quantidade</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="adicionar_ao_carrinho.php" method="post" style="display: inline;">
                    <div class="modal-body">
                        <h3>Selecione a quantidade</h3>

                        <label for="qtde">Quantidade</label> <!--qtde-->
                        <input type="number" id="pro_qtde" class="input" name="pro_qtde" placeholder="" value="1" required min="1">
                        <input type="hidden" id="pro_cod" class="input" name="pro_cod" required="">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary btn-login">Adicionar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!--MODAL - Sair-->
    <div class="modal fade" id="modalsair" tabindex="-1" role="dialog" aria-labelledby="modalsair" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="modalsair">Sair</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h3>Deseja realmente sair?</h3>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <form action="../back-end/sair.php" method="post" style="display: inline;">
                        <input type="hidden" id="pro_cod" name="pro_cod" value="">
                        <button type="submit" class="btn btn-danger">Confirmar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- JS Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>

    <!--JS do popover-->
    <script>
        function setProCode(proCod, proQtde) {
            // Preenche os campos do modal de carrinho com os dados do funcionário
            document.getElementById('pro_cod').value = proCod;
            const inputQuantidade = document.getElementById('pro_qtde');
            inputQuantidade.max = proQtde;
            inputQuantidade.value = 1;
        }



        $(document).ready(function() {
            $('[data-toggle="popover"]').popover();
        });

        $(document).ready(function() {
            $('[data-toggle="popover"]').popover({
                trigger: 'manual',
                delay: {
                    "show": 500,
                    "hide": 2000
                }
            }).on("mouseenter", function() {
                var _this = this;
                $(this).popover("show");
                $(".popover").on("mouseleave", function() {
                    $(_this).popover('hide');
                });
            }).on("mouseleave", function() {
                var _this = this;
                setTimeout(function() {
                    if (!$(".popover:hover").length) {
                        $(_this).popover("hide");
                    }
                }, 200);
            });
        });
    </script>
</body>

</html>