<?php
require '../conexao.php';
mysqli_set_charset($con, 'utf8');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['resv_cod'])) {
    $resv_cod = mysqli_real_escape_string($con, $_POST['resv_cod']);

    $sql = "SELECT p.pro_nome, p.pro_foto, ir.itrer_preco, ir.itrer_qtde 
            FROM Itens_Reserva ir 
            INNER JOIN Produtos p ON ir.pro_cod = p.pro_cod 
            WHERE ir.resv_cod = '$resv_cod'";

    $result = mysqli_query($con, $sql);

    $data = [];
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
    }

    echo json_encode($data);
    exit;
}
?>
