<?php 
ini_set('default_charset','UTF-8');
require('../../bibliotecas/fpdf/fpdf.php'); 
require('../../conexao.php'); // Conecte-se ao banco de dados

class PDF extends FPDF 
{ 
    function Header() 
    { 
        $this->Image('../../img/logo png.png',10,6,30);
        $this->SetY(20); // Ajusta a posição do título após a imagem
        $this->SetFont('Arial', 'B', 15); 
        $this->Cell(0, 10, 'Lista de Funcionarios', 0, 1, 'C'); // Alinhamento centralizado
        $this->Ln(10); // Espaçamento após o cabeçalho
    } 

    function Footer() 
    {  
        $this->SetY(-15); // Ajusta a posição do rodapé
        $this->SetFont('Arial', '', 10); 
        $this->Cell(0, 10, 'Pagina '.$this->PageNo().'/{nb}', 0, 0, 'C');
    } 

    function FancyTable($header, $data)
    {
        // Configuração das cores e fonte
        $this->SetFillColor(126, 217, 87);
        $this->SetDrawColor(20, 71, 36);
        $this->SetFont('Arial','B',12);
        // Larguras das colunas
        $w = array(75, 40, 75);
        for($i=0; $i < count($header); $i++) {
            $this->Cell($w[$i], 7, $header[$i], 1, 0, 'C', true);
        }
        $this->Ln(); // Linha nova após o cabeçalho
        // Dados
        $this->SetFont('Arial','',12);
        $fill = false;
        foreach($data as $row)
        {
            $this->Cell($w[0], 6, $row['fun_nome'], 'LR', 0, 'L', $fill);
            $this->Cell($w[1], 6, $row['fun_telefone'], 'LR', 0, 'L', $fill);
            $this->Cell($w[2], 6, $row['fun_email'], 'LR', 0, 'L', $fill);
            $this->Ln();
            $fill = !$fill;
        }
        // Linha de fechamento
        $this->Cell(array_sum($w), 0, '', 'T');
    }
}  

// Criação do PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Cabeçalho da tabela
$header = array('Nome', 'Telefone', 'Email');

// Consulta ao banco de dados
$con = new mysqli('localhost', 'root', '', 'cooperativa'); // Atualize com suas credenciais

if ($con->connect_error) {
    die("Conexão falhou: " . $con->connect_error);
}

$sql = "SELECT fun_nome, fun_telefone, fun_email FROM Funcionarios";
$result = $con->query($sql);

$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

$pdf->FancyTable($header, $data);
$pdf->Output();

?>
