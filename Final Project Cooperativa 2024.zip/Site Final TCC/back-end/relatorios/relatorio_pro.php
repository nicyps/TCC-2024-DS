<?php 
ini_set('default_charset','UTF-8');
require('../../bibliotecas/fpdf/fpdf.php'); 
require('../../conexao.php'); // Conecte-se ao banco de dados

class PDF extends FPDF 
{ 
    function Header() 
    { 
        $this->Image('../../img/logo png.png',10,6,30);
        $this->SetY(20); // Ajusta a posição do título após a imagem
        $this->SetFont('Arial', 'B', 15); 
        $this->Cell(0, 10, 'Lista de Produtos', 0, 1, 'C'); // Alinhamento centralizado
        $this->Ln(10); // Espaçamento após o cabeçalho
    } 

    function Footer() 
    {  
        $this->SetY(-15); // Ajusta a posição do rodapé
        $this->SetFont('Arial', '', 10); 
        $this->Cell(0, 10, 'Pagina '.$this->PageNo().'/{nb}', 0, 0, 'C');
    } 

    function FancyTable($header, $data)
    {
        // Configuração das cores e fonte
        $this->SetFillColor(126, 217, 87);
        $this->SetDrawColor(20, 71, 36);
        $this->SetFont('Arial','B',15);

        // Larguras das colunas
        $w = array(15, 35, 35, 35, 17); // Ajuste de larguras das colunas
        $totalWidth = array_sum($w);

        // Centralize a tabela calculando a posição X inicial
        $this->SetX(($this->w - $totalWidth) / 2); // $this->w é a largura total da página

        // Cabeçalho
        for($i=0; $i < count($header); $i++) {
            $this->Cell($w[$i], 7, $header[$i], 1, 0, 'C', true);
        }
        $this->Ln(); // Linha nova após o cabeçalho

        // Dados
        $this->SetFont('Arial','',15);
        $fill = false;
        foreach($data as $row)
        {
            $this->SetX(($this->w - $totalWidth) / 2); // Centralize cada linha de dados também
            $this->Cell($w[0], 6, $row['pro_cod'], 'LR', 0, 'L', $fill);
            $this->Cell($w[1], 6, $row['pro_nome'], 'LR', 0, 'L', $fill);
            $this->Cell($w[2], 6, number_format($row['pro_preco'], 2, ',', '.'), 'LR', 0, 'L', $fill);
            $this->Cell($w[3], 6, $row['pro_qtde'], 'LR', 0, 'L', $fill);

            // Exibir a imagem do produto redimensionada
            if (file_exists('../' . $row['pro_foto'])) {
                $this->Image('../' . $row['pro_foto'], $this->GetX(), $this->GetY(), 17, 17, 'png');
            } else {
                $this->Cell($w[4], 20, 'Imagem N/A', 'LR', 0, 'C', $fill);
            }
            $this->Ln(17); // Espaçamento entre linhas para imagens maiores
            $fill = !$fill;
        }
        // Linha de fechamento
        $this->Cell($totalWidth, 0, '', 'T');
    }

}  

// Criação do PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Cabeçalho da tabela
$header = array('Cod', 'Nome', 'Preco', 'Quantidade', 'Foto');

// Consulta ao banco de dados
$con = new mysqli('localhost', 'root', '', 'cooperativa'); // Atualize com suas credenciais

if ($con->connect_error) {
    die("Conexão falhou: " . $con->connect_error);
}

$sql = "SELECT pro_cod, pro_nome, pro_preco, pro_qtde, pro_foto FROM Produtos order by pro_nome asc";
$result = $con->query($sql);

$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

$pdf->FancyTable($header, $data);
$pdf->Output();

?>
