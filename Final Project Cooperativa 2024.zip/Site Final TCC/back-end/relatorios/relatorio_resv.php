<?php
ini_set('default_charset','UTF-8');
require('../../bibliotecas/fpdf/fpdf.php');
require('../../conexao.php'); // Conexão ao banco de dados

class PDF extends FPDF
{
    function Header()
    {
        $this->Image('../../img/logo.png', 10, 6, 30); // Atualize o caminho da imagem se necessário
        $this->SetY(20); // Posição do título após a imagem
        $this->SetFont('Arial', 'B', 15);
        $this->Cell(0, 10, 'Lista de Reservas', 0, 1, 'C'); // Alinhamento centralizado
        $this->Ln(10); // Espaçamento após o cabeçalho
    }

    function Footer()
    {
        $this->SetY(-15); // Posição do rodapé
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 10, 'Página '.$this->PageNo().'/{nb}', 0, 0, 'C');
    }

    function FancyTable($header, $data)
    {
        // Configurações de cores e fonte
        $this->SetFillColor(126, 217, 87);
        $this->SetDrawColor(20, 71, 36);
        $this->SetFont('Arial', 'B', 12);

        // Largura das colunas
        $w = array(20, 30, 20, 20, 60, 25); // Ajuste de larguras conforme necessário
        $totalWidth = array_sum($w);

        // Centralizar tabela
        $this->SetX(($this->w - $totalWidth) / 2);

        // Cabeçalho
        foreach($header as $i => $col) {
            $this->Cell($w[$i], 7, $col, 1, 0, 'C', true);
        }
        $this->Ln();

        // Dados
        $this->SetFont('Arial', '', 10);
        $fill = false;
        foreach($data as $row) {
            $this->SetX(($this->w - $totalWidth) / 2);
            $this->Cell($w[0], 6, $row['resv_cod'], 'LR', 0, 'L', $fill);
            $this->Cell($w[1], 6, $row['resv_data'], 'LR', 0, 'L', $fill);
            $this->Cell($w[2], 6, $row['resv_tipo'], 'LR', 0, 'L', $fill);
            $this->Cell($w[3], 6, number_format($row['resv_total'], 2, ',', '.'), 'LR', 0, 'R', $fill);
            $this->Cell($w[4], 6, $row['cli_email'], 'LR', 0, 'L', $fill);
            $this->Cell($w[5], 6, $row['resv_status'], 'LR', 0, 'C', $fill);
            $this->Ln();
            $fill = !$fill;
        }
        $this->Cell($totalWidth, 0, '', 'T');
    }
}

// Criação do PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Cabeçalho da tabela
$header = array('Cod', 'Data', 'Tipo', 'Total', 'Cliente', 'Status');

// Conexão ao banco de dados
$con = new mysqli('localhost', 'root', '', 'cooperativa'); // Atualize as credenciais

if ($con->connect_error) {
    die("Conexão falhou: " . $con->connect_error);
}

// Consulta à tabela Reservas
$sql = "SELECT resv_cod, DATE_FORMAT(resv_data, '%d/%m/%Y') AS resv_data, resv_tipo, resv_total, cli_email, resv_status FROM Reservas ORDER BY resv_data ASC";
$result = $con->query($sql);

$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Gerar o relatório
$pdf->FancyTable($header, $data);
$pdf->Output();
?>
