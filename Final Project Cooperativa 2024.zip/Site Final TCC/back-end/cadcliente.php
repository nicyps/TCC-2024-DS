<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cooperativa | Etec 032</title>
    <!--ICON-->
    <link rel="shortcut icon" type="imagex/png" href="../img/logo ico.ico">
    <!--FONTES-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Acme&family=Cabin:ital,wght@0,400..700;1,400..700&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap"
        rel="stylesheet">
    <!--CSS Do BootStrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--CSS externo-->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/login.css">

    <!--CSS BOX ICONS-->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        #footer {
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            padding-top: 20px;
            background-color: #158451;
            color: #ffffff;
            font-size: 18px;
        }
        </style>
</head>

<body>
    <!--navbar-->
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="../front-end/index.html">
            <img src="../img/widelogo.png" width="180" height="60" class="d-inline-block align-top" alt="" href="index.html">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
            aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Alterna navegação">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse nav-item justify-content-end">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="lista_funcionarios.php"><i class='bx bx-briefcase' data-toggle="popover" data-html="true"
                        data-placement="bottom"
                        data-content="Entrar como funcionário."></i></a>
                </li>
            </ul>
        </div>
    </nav>

    <!--cadastro-->
    <section id="login">
        <div class="container container-login">
            
            <?php
                ini_set('default_charset','UTF-8');
                $cli_nome = $_POST['cli_nome'];
                $cli_email = $_POST['cli_email'];
                $cli_tel = $_POST['cli_telefone'];
                $cli_senha = $_POST['cli_senha'];
                
                $hashed_senha = password_hash($cli_senha, PASSWORD_DEFAULT);

                require '../conexao.php';
                
                if ($con)
                {
                    mysqli_set_charset($con, "utf8");

                    $sql=" insert into Clientes (cli_nome, cli_telefone, cli_email, cli_senha) values ('$cli_nome', '$cli_tel', '$cli_email', '$hashed_senha')";
                    if (mysqli_query($con, $sql)){
                        echo "<h3><span class='trace trace-php'>Cadastro</span> realizado com sucesso!</h3>";
                        header("refresh:2;url=../front-end/login.html");
                    }
                        else
                            echo "<br>Não foi possível realizar o cadastro. <br> Erro: ".mysqli_error($con);
                    mysqli_close($con);
                }
                else
                    echo 'Não foi possível conectar com o banco de dados.';
                echo "<a  href='../login.html'><i class='bx bx-left-arrow-alt' style='font-size: 30px; color: #158451; font-weight: 700;'></i></a>";
            ?>
            
        </div>
        <br>
    </section>


    <!--FOOTER-->
    <footer id="footer">
        <div class="footer-content">
            <div class="footer-content-quicklinks">
                <h5>Acesso Rápido</h5>
                <ul>
                    <li class="quicklinks"><a href="#">Início</a></li>
                    <li class="quicklinks"><a href="#sobre">Sobre</a></li>
                    <li class="quicklinks"><a href="#produtos">Produtos</a></li>
                </ul>
            </div>
            <div class="footer-content-contact">
                <h5>Contatos</h5>
                <p>(18) 3222-8466</p>
                <p>(18) 98196-1025</p>
                <p>etecppagricola@gmail.com</p>
                <p>SP-270, 561 - Pres. Prudente - SP</p>
            </div>
            <div class="footer-content-socials">
                <h5>Redes Sociais</h5>
                <a href="https://www.instagram.com/colegioagricolaprudenteoficial/"><i class='bx bxl-instagram'></i>
                    Instagram</a><br>
                <a href="https://www.facebook.com/colegioagricolaprudenteoficial/?locale=pt_BR"><i
                        class='bx bxl-facebook'></i> Facebook</a> <br>
                <a href="https://web.whatsapp.com/send?phone=5518981961025"><i class='bx bxl-whatsapp'></i> WhatsApp</a>
            </div>
        </div>
        <br>
        <p>&copy; 2024
    </footer>

    <!-- JS Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>

        <!--JS do popover-->
        <script>
            $(document).ready(function () {
                $('[data-toggle="popover"]').popover();
            });

            $(document).ready(function () {
                $('[data-toggle="popover"]').popover({
                    trigger: 'manual',
                    delay: { "show": 500, "hide": 2000 }
                }).on("mouseenter", function () {
                    var _this = this;
                    $(this).popover("show");
                    $(".popover").on("mouseleave", function () {
                        $(_this).popover('hide');
                    });
                }).on("mouseleave", function () {
                    var _this = this;
                    setTimeout(function () {
                        if (!$(".popover:hover").length) {
                            $(_this).popover("hide");
                        }
                    }, 200);
                });
            });
        </script>
    </body>
</html>