<?php
session_start();
require '../conexao.php';

header('Content-Type: application/json');

// Verifica se os dados foram enviados
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['pro_cod'], $data['action'])) {
    echo json_encode(['success' => false, 'message' => 'Dados inválidos.']);
    exit;
}

$cli_email = $_SESSION['log_email'];
$pro_cod = $data['pro_cod'];
$action = $data['action'];

mysqli_set_charset($con, 'utf8');

if ($action === 'increment') {
    $query = "UPDATE Carrinhos SET itcar_qtde = itcar_qtde + 1 WHERE cli_email = '$cli_email' AND pro_cod = $pro_cod";
} elseif ($action === 'decrement') {
    $query = "UPDATE Carrinhos SET itcar_qtde = GREATEST(itcar_qtde - 1, 1) WHERE cli_email = '$cli_email' AND pro_cod = $pro_cod";
} else {
    echo json_encode(['success' => false, 'message' => 'Ação inválida.']);
    exit;
}

if (mysqli_query($con, $query)) {
    // Obtém os valores atualizados
    $result = mysqli_query($con, "SELECT itcar_qtde, (itcar_qtde * Produtos.pro_preco) AS item_total FROM Carrinhos 
                                  INNER JOIN Produtos ON Carrinhos.pro_cod = Produtos.pro_cod 
                                  WHERE cli_email = '$cli_email' AND Carrinhos.pro_cod = $pro_cod");

    $row = mysqli_fetch_assoc($result);
    $item_total = $row['item_total'];
    $new_quantity = $row['itcar_qtde'];

    // Calcula o total do carrinho
    $result = mysqli_query($con, "SELECT SUM(itcar_qtde * Produtos.pro_preco) AS cart_total FROM Carrinhos 
                                  INNER JOIN Produtos ON Carrinhos.pro_cod = Produtos.pro_cod 
                                  WHERE cli_email = '$cli_email'");

    $row = mysqli_fetch_assoc($result);
    $cart_total = $row['cart_total'];

    echo json_encode([
        'success' => true,
        'new_quantity' => $new_quantity,
        'item_total' => $item_total,
        'cart_total' => $cart_total,
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Erro ao atualizar o banco de dados.']);
}
mysqli_close($con);
?>
