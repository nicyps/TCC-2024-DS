<?php session_start(); ?>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cooperativa | Etec 032</title>
    <!--ICON-->
    <link rel="shortcut icon" type="imagex/png" href="../img/logo ico.ico">
    <!--FONTES-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Cabin:ital,wght@0,400..700;1,400..700&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap" rel="stylesheet">
    <!--CSS Do BootStrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--CSS externo-->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/carrinho.css">
    <link rel="stylesheet" href="../css/login.css">

    <!--CSS BOX ICONS-->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <!--navbar-->
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#" onclick="location.reload();">
            <img src="../img/widelogo.png" width="180" height="60" class="d-inline-block align-top" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
            aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Alterna navegação">
            <span class="navbar-toggler-icon"></span>
        </button>

        <ul class="navbar-nav" style="margin-left: 20px;">
            <div class="collapse navbar-collapse nav-item justify-content-end">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../back-end/produtos.php">Todos Produtos</a>
                    </li>
                </ul>
            </div>
        </ul>

        <div class="collapse navbar-collapse nav-item justify-content-end" id="conteudoNavbarSuportado">
            <!--pesquisar btn-->
            <form class="form-inline my-2 my-lg-0" action="pesquisa_produtos.php" method="GET">
                <input class="form-control mr-sm-2" type="search" name="q" placeholder="Pesquisar" aria-label="Pesquisar">
                <button class="btn btn-outline my-2 my-sm-0" type="submit"><i class='bx bx-search'></i></button>
            </form>
            <!--itens-->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="../front-end/carrinho.php"><i class='bx bx-cart' data-toggle="popover" data-html="true"
                            data-placement="bottom"
                            data-content="Ver Carrinho!"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../front-end/perfilcliente.php"><i class='bx bx-user-circle'></i></a>
                </li>
            </ul>
        </div>
    </nav>

    <section id="perfil">
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div class="container container-login">

            <?php
            ini_set('default_charset', 'UTF-8');
            require '../conexao.php';
            mysqli_set_charset($con, 'utf8');

            $resv_cod = $_GET['resv_cod'];

            $sql = "UPDATE Reservas SET resv_status = 'Retirada' WHERE resv_cod = $resv_cod;";

            if (mysqli_query($con, $sql))  {
                echo "<h3><span class='trace trace-php'>Finalizada</span> com sucesso!</h3>";
                header("refresh:1;url=../front-end/fun_reservas.php");
            }
            else{
                echo "<br>Não foi possível Finalizada. <br> Erro: " . mysqli_error($con);
                header("refresh:2;url=../front-end/fun_reservas.php");
            }
            ?>


        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
    </section>

    <!--FOOTER-->
    <footer id="footer">
        <div class="footer-content">
            <div class="footer-content-quicklinks">
                <h5>Acesso Rápido</h5>
                <ul>
                    <li class="quicklinks"><a href="index.html">Início</a></li>
                    <li class="quicklinks"><a href="index.html">Sobre</a></li>
                    <li class="quicklinks"><a href="#produtos">Produtos</a></li>
                </ul>
            </div>
            <div class="footer-content-contact">
                <h5>Contatos</h5>
                <p>(18) 3222-8466</p>
                <p>(18) 98196-1025</p>
                <p>etecppagricola@gmail.com</p>
                <p>SP-270, 561 - Pres. Prudente - SP</p>
            </div>
            <div class="footer-content-socials">
                <h5>Redes Sociais</h5>
                <a href="https://www.instagram.com/colegioagricolaprudenteoficial/"><i class='bx bxl-instagram'></i> Instagram</a><br>
                <a href="https://www.facebook.com/colegioagricolaprudenteoficial/?locale=pt_BR"><i class='bx bxl-facebook'></i> Facebook</a> <br>
                <a href="https://web.whatsapp.com/send?phone=5518981961025"><i class='bx bxl-whatsapp'></i> WhatsApp</a>
            </div>
        </div>
        <br>
        <p>&copy; 2024
    </footer>

    


    <!-- JS Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <!--JS do popover-->
    <script>
        $(document).ready(function() {
            $('[data-toggle="popover"]').popover();
        });

        $(document).ready(function() {
            $('[data-toggle="popover"]').popover({
                trigger: 'manual',
                delay: {
                    "show": 500,
                    "hide": 2000
                }
            }).on("mouseenter", function() {
                var _this = this;
                $(this).popover("show");
                $(".popover").on("mouseleave", function() {
                    $(_this).popover('hide');
                });
            }).on("mouseleave", function() {
                var _this = this;
                setTimeout(function() {
                    if (!$(".popover:hover").length) {
                        $(_this).popover("hide");
                    }
                }, 200);
            });
        });
    </script>


</body>

</html>