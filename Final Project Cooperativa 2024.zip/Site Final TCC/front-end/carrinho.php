<?php session_start(); ?>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cooperativa | Etec 032</title>
    <!--ICON-->
    <link rel="shortcut icon" type="imagex/png" href="../img/logo ico.ico">
    <!--FONTES-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Acme&family=Cabin:ital,wght@0,400..700;1,400..700&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap" rel="stylesheet">
    <!--CSS Do BootStrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--CSS externo-->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/carrinho.css">

    <!--CSS BOX ICONS-->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>
    <!--navbar-->
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#" onclick="location.reload();">
            <img src="../img/widelogo.png" width="180" height="60" class="d-inline-block align-top" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
            aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Alterna navegação">
            <span class="navbar-toggler-icon"></span>
        </button>

        <ul class="navbar-nav" style="margin-left: 20px;">
            <div class="collapse navbar-collapse nav-item justify-content-end">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../back-end/produtos.php">Todos Produtos</a>
                    </li>
                </ul>
            </div>
        </ul>

        <div class="collapse navbar-collapse nav-item justify-content-end" id="conteudoNavbarSuportado">
            <!--pesquisar btn-->
            <form class="form-inline my-2 my-lg-0" action="pesquisa_produtos.php" method="GET">
                <input class="form-control mr-sm-2" type="search" name="q" placeholder="Pesquisar" aria-label="Pesquisar">
                <button class="btn btn-outline my-2 my-sm-0" type="submit"><i class='bx bx-search'></i></button>
            </form>
            <!--itens-->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="../front-end/carrinho.php"><i class='bx bx-cart' data-toggle="popover" data-html="true"
                            data-placement="bottom"
                            data-content="Ver Carrinho!"></i></a>
                </li>
                <li class="nav-item">
                    <div class="dropdown">
                        <a class="nav-link" href="" id="dropdown-perfil" data-toggle="dropdown"><i class='bx bx-user-circle'></i></a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-perfil">
                            <a class="dropdown-item" href="../front-end/perfilcliente.php">Perfil</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-danger" href="" data-toggle='modal' data-target='#modalsair'>Sair</a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </nav>

    <!--carrinho-->
    <section id="carrinho">
        <H1 style="color: white;"><span class="trace">|</span>Seu carrinho</H1>
        <div class="voltar">
            <a href="../back-end/produtos.php"><i class='bx bx-left-arrow-alt' style="font-size: 35px; color: #158451; font-weight: 700;"></i></a>
        </div>
        <br>
        <div class="carrinho">
            <div class='cart'>
                <?php

                ini_set('default_charset', 'UTF-8');
                require '../conexao.php';

                $cli_email = $_SESSION['log_email'];

                $totalcar = 0;

                mysqli_set_charset($con, 'utf8');

                if ($con) {
                    $sql = "
                                SELECT 
                                    Carrinhos.pro_cod, 
                                    Carrinhos.itcar_qtde, 
                                    Carrinhos.itcar_preco, 
                                    Produtos.pro_nome, 
                                    Produtos.pro_preco AS produto_preco, 
                                    Produtos.pro_qtde, 
                                    Produtos.pro_dt_validade, 
                                    Produtos.pro_foto 
                                FROM 
                                    Carrinhos 
                                INNER JOIN 
                                    Produtos 
                                ON 
                                    Carrinhos.pro_cod = Produtos.pro_cod 
                                WHERE 
                                    Carrinhos.cli_email = '$cli_email'
                                ORDER BY 
                                    Produtos.pro_nome;
                            ";

                    $result = mysqli_query($con, $sql);
                    mysqli_close($con);

                    while ($dados = mysqli_fetch_assoc($result)) {
                        $pro_cod = $dados['pro_cod'];
                        $itcar_qtde = $dados['itcar_qtde'];
                        $itcar_preco = $dados['itcar_preco'];
                        $pro_nome = $dados['pro_nome'];
                        $produto_preco = $dados['produto_preco'];
                        $pro_qtde = $dados['pro_qtde'];
                        $pro_dt_validade = $dados['pro_dt_validade'];
                        $pro_foto = $dados['pro_foto'];

                        $totalpro = $itcar_qtde * $produto_preco;

                        echo "
                                    <div class='item shadow-lg' > <!-- ITEM COMPLETO -->
                                        <div class='item-details'>
                                            <img src='$pro_foto'>
                                            <div>
                                                <h3>$pro_nome</h3> <!-- nome -->
                                                <p>Validade: $pro_dt_validade<br> <!-- validade -->
                                                    $pro_qtde unidades disponíveis</p> <!-- estoque -->
                                                <p>R$ $produto_preco/ unidade</p> <!-- preço -->
                                            </div>
                                        </div>
                                        <div class='item-actions'>
                                            <i class='bx bx-x' data-toggle='modal' data-target='#modaldelete' onclick='setDeleteCode($pro_cod)'></i>
                                            <p>Total: R$ " . number_format($totalpro, 2, ',', '.') . "</p> 
                                            <div class='quantity-input'>
                                                <button class='minus' data-pro-cod='$pro_cod'>-</button>
                                                <input type='number' value='$itcar_qtde' min='1' max='$pro_qtde'>
                                                <button class='plus' data-pro-cod='$pro_cod'>+</button>
                                            </div>
                                        </div>
                                    </div>
                                ";

                        $totalcar = $totalcar + $totalpro;
                    }
                }


                ?>
            </div>
            <div class="summary shadow-lg ">
                <h2><span class="trace">Resumo</span> da reserva</h2>
                <hr style="width: 80%;">
                <br>
                <h3>Total: <strong>R$ <?php echo number_format($totalcar, 2, ',', '.') ?></strong></h3>
                <p>Forma de Pagamento:
                    <select name="resv_tipo" id="tipoInput" class="styled-select">
                        <option>Escolher...</option>
                        <option value="Cartão-Crédito">Cartão-Crédito</option>
                        <option value="Cartão-Débito">Cartão-Débito</option>
                        <option value="Dinheiro">Dinheiro</option>
                        <option value="Pix">Pix</option>
                    </select>
                </p>
                <p>Data da retirada: <strong><input type="date" id="dateInput"></strong></p>
                <p class="note">*Somente <span class="trace">TERÇAS</span> e <span class="trace">SEXTAS feiras</span> estão disponiveis para a retirada</p>
                <button class="btn btn-primary btn-login" data-toggle="modal" data-target="#modalExemplo" id="finalizeButton">Finalizar reserva</button>
                <br>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
    </section>

    <!--FOOTER-->
    <footer id="footer">
        <div class="footer-content">
            <div class="footer-content-quicklinks">
                <h5>Acesso Rápido</h5>
                <ul>
                    <li class="quicklinks"><a href="index.html">Início</a></li>
                    <li class="quicklinks"><a href="index.html">Sobre</a></li>
                    <li class="quicklinks"><a href="#produtos">Produtos</a></li>
                </ul>
            </div>
            <div class="footer-content-contact">
                <h5>Contatos</h5>
                <p>(18) 3222-8466</p>
                <p>(18) 98196-1025</p>
                <p>etecppagricola@gmail.com</p>
                <p>SP-270, 561 - Pres. Prudente - SP</p>
            </div>
            <div class="footer-content-socials">
                <h5>Redes Sociais</h5>
                <a href="https://www.instagram.com/colegioagricolaprudenteoficial/"><i class='bx bxl-instagram'></i> Instagram</a><br>
                <a href="https://www.facebook.com/colegioagricolaprudenteoficial/?locale=pt_BR"><i class='bx bxl-facebook'></i> Facebook</a> <br>
                <a href="https://web.whatsapp.com/send?phone=5518981961025"><i class='bx bxl-whatsapp'></i> WhatsApp</a>
            </div>
        </div>
        <br>
        <p>&copy; 2024
    </footer>

    <!--MODAL - Excluir-->
    <div class="modal fade" id="modaldelete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Remover Produto</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h3>Deseja <span class="trace">Remover</span> este <span class="trace">produto</span> do <span class="trace">carrinho</span>?</h3>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <form action="../back-end/excluir_produto_carrinho.php" method="post" style="display: inline;">
                        <input type="hidden" id="pro_cod" name="pro_cod" value="">
                        <button type="submit" class="btn btn-danger">Confirmar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="modalExemplo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Confirmar reserva?</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Para dia <b id="selectedDate">[Data a ser preenchida]</b> <!--alterar data-->
                    <br> Dirija-se até o Colégio Agrícola e faça a retirada e pagamento por <b id="selectedTipo">[Tipo a ser preenchida]</b> do seu pedido presencialmente.
                    <p class="note">*Caro cliente, caso não cumpra com a data seu pedido será cancelado.</p>
                </div>
                <div class="modal-footer">
                    <form action="../back-end/finalizar_reserva.php" method="post">
                        <input type="hidden" id="resv_data" class="input" name="resv_data" required="">
                        <input type="hidden" id="resv_tipo" class="input" name="resv_tipo" required="">
                        <input type="hidden" id="total_car" class="input" name="total_car" required="" value="<?php echo $totalcar?>">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-secondary-alt">Confirmar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!--MODAL - Sair-->
    <div class="modal fade" id="modalsair" tabindex="-1" role="dialog" aria-labelledby="modalsair" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="modalsair">Sair</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h3>Deseja realmente sair?</h3>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <form action="../back-end/sair.php" method="post" style="display: inline;">
                        <input type="hidden" id="pro_cod" name="pro_cod" value="">
                        <button type="submit" class="btn btn-danger">Confirmar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- JS Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <!--JS do popover-->
    <script>
        function setDeleteCode(proCod) {
            document.getElementById('pro_cod').value = proCod;
        }

        $(document).ready(function() {
            $('[data-toggle="popover"]').popover();
        });

        $(document).ready(function() {
            $('[data-toggle="popover"]').popover({
                trigger: 'manual',
                delay: {
                    "show": 500,
                    "hide": 2000
                }
            }).on("mouseenter", function() {
                var _this = this;
                $(this).popover("show");
                $(".popover").on("mouseleave", function() {
                    $(_this).popover('hide');
                });
            }).on("mouseleave", function() {
                var _this = this;
                setTimeout(function() {
                    if (!$(".popover:hover").length) {
                        $(_this).popover("hide");
                    }
                }, 200);
            });
        });

        document.addEventListener('DOMContentLoaded', function() {
            const minusButtons = document.querySelectorAll('.minus');
            const plusButtons = document.querySelectorAll('.plus');

            function updateQuantity(proCod, action) {
                // Realiza uma requisição AJAX para o servidor
                fetch('../back-end/atualizar_quantidade.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            pro_cod: proCod,
                            action: action
                        }),
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            location.reload();
                        } else {
                            alert(data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Erro ao atualizar o carrinho:', error);
                    });
            }

            minusButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const proCod = button.dataset.proCod;
                    updateQuantity(proCod, 'decrement');
                });
            });

            plusButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const proCod = button.dataset.proCod;
                    updateQuantity(proCod, 'increment');
                });
            });
        });

        const dateInput = document.getElementById('dateInput');

        dateInput.addEventListener('change', function() {
            const selectedDate = new Date(this.value);
            const dayOfWeek = selectedDate.getDay(); // 0 = Domingo, 1 = Segunda, ..., 6 = Sábado

            if (dayOfWeek !== 1 && dayOfWeek !== 4) { // 2 = Terça, 5 = Sexta
                alert("Por favor, selecione apenas uma terça-feira ou sexta-feira.");
                this.value = ''; // Limpa o valor inválido
            }
        });

        document.getElementById('finalizeButton').addEventListener('click', function() {
            // Obtém o valor do input de data
            const dateInput = document.getElementById('dateInput').value;
            const tipoSelect = document.getElementById('tipoInput').value;

            // Verifica se há uma data selecionada
            if (dateInput) {
                // Usar a data do input diretamente (já no formato YYYY-MM-DD)
                const [year, month, day] = dateInput.split('-'); // Divide a string em ano, mês, dia
                const formattedDate = `${day} de ${getMonthName(month)} de ${year}`; // Formata a data

                // Atualiza o conteúdo do modal com a data selecionada
                if (tipoSelect !== "Escolher...") { // Verifica se não foi escolhida a opção padrão
                    document.getElementById('selectedDate').textContent = formattedDate;
                    document.getElementById('selectedTipo').textContent = tipoSelect; // Atualiza o tipo de pagamento
                    document.getElementById('resv_data').value = dateInput;
                    document.getElementById('resv_tipo').value = tipoSelect;
                } else {
                    document.getElementById('selectedTipo').textContent = 'nenhuma forma de pagamento selecionada';
                    document.getElementById('resv_tipo').value = '';
                }
            } else {
                document.getElementById('selectedDate').textContent = 'nenhuma data selecionada';
                document.getElementById('resv_data').value = '';
            }
        });


        // Função para obter o nome do mês
        function getMonthName(month) {
            const months = [
                'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
                'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'
            ];
            return months[parseInt(month, 10) - 1]; // Converte o mês para índice (1 baseado para 0 baseado)
        }
    </script>


</body>

</html>