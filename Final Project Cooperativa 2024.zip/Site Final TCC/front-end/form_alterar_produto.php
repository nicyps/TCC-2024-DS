<html lang="pt-br"></html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cooperativa | Etec 032</title>
    <!--ICON-->
    <link rel="shortcut icon" type="imagex/png" href="../img/logo ico.ico">
    <!--FONTES-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Acme&family=Cabin:ital,wght@0,400..700;1,400..700&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap"
        rel="stylesheet">
    <!--CSS Do BootStrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--CSS externo-->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/login.css">
    <link rel="stylesheet" href="../css/carrinho.css">

    <!--CSS BOX ICONS-->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <!--css interno-->
    <style>
        .modal-title{
            text-align: center;
        }
    
        #footer {
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            padding-top: 20px;
            background-color: #158451;
            color: #ffffff;
            font-size: 18px;
        }
    </style>
</head>

<body>
    <!--navbar-->
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#" onclick="location.reload();">
            <img src="../img/widelogo.png" width="180" height="60" class="d-inline-block align-top" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
            aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Alterna navegação">
            <span class="navbar-toggler-icon"></span>
        </button>

        <ul class="navbar-nav" style="margin-left: 20px;">
            <div class="collapse navbar-collapse nav-item justify-content-end">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../back-end/visuestoque.php">Estoque</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="relatorios.html">Relatórios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_funcionarios.php">Funcionários</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="fun_reservas.php">Reservas</a>
                    </li>
                </ul>
            </div>
        </ul>

        <div class="collapse navbar-collapse nav-item justify-content-end" id="conteudoNavbarSuportado">
            <!--pesquisar btn-->
            <form class="form-inline my-2 my-lg-0" action="../back-end/pesquisa_estoque.php" method="GET">
                <input class="form-control mr-sm-2" type="search" name="q" placeholder="Pesquisar"
                    aria-label="Pesquisar">
                <button class="btn btn-outline my-2 my-sm-0" type="submit"><i class='bx bx-search'></i></button>
            </form>
            <!--itens-->
            <ul class="navbar-nav">
                <div class="collapse navbar-collapse nav-item justify-content-end">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <div class="dropdown">
                                <a class="nav-link" href="" id="dropdown-perfil" data-toggle="dropdown"><i
                                        class='bx bx-user-circle'></i></a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-perfil">
                                    <a class="dropdown-item" href="perfil_funcionario.php">Perfil</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="#" data-toggle='modal'
                                        data-target='#modalsair'>Sair</a>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </ul>
        </div>
    </nav>
    <?php
    
    $pro_cod = $_GET['pro_cod'];

    ini_set('default_charset', 'UTF-8');
    require '../conexao.php';
    mysqli_set_charset($con, 'utf8');

    $sql = "select * from Produtos where pro_cod=$pro_cod";

    $result = mysqli_query($con, $sql);
    $dados = mysqli_fetch_assoc($result);

    $pro_cod = $dados['pro_cod'];
    $pro_nome = $dados['pro_nome'];
    $pro_qtde = $dados['pro_qtde'];
    $pro_preco = $dados['pro_preco'];
    $pro_dt_validade = $dados['pro_dt_validade'];
    $pro_foto_antiga = $dados['pro_foto'];

    ?>

    <!--alt-->
    <section id="login">
        <div class="container container-login">
            <h3>Alterar <span class="trace">Produto</span></h3>
            <form class="form-login" action="../back-end/alterar_produto.php" method="post" enctype="multipart/form-data">
                <div class="form-group-login">
                    <label for="nome">Nome do Produto</label> <!--email-->
                    <input type="text" id="pro_nome" class="input" name="pro_nome" placeholder="Digite o nome" required="" value= <?php echo $pro_nome ?>>
                    <label for="qtde">Quantidade</label> <!--qtde-->
                    <input type="number" id="pro_qtde" class="input" name="pro_qtde" placeholder="Digite a qtde. disponível" required="" value= <?php echo $pro_qtde ?>>
                    <label for="qtde">Preço unitário</label> <!--preço-->
                    <input type="number " id="pro_preco" class="input" name="pro_preco" placeholder="Digite o preço por unidade" required="" value= <?php echo $pro_preco ?>>
                    <label for="qtde">Data de Validade</label> <!--validade-->
                    <input type="date" id="pro_dt_validade" class="input" name="pro_dt_validade" placeholder="Digite a validade deste lote" required="" value= <?php echo $pro_dt_validade ?>>
                    <label for="foto">Insira uma foto do produto Nova</label>
                    <input type="file" class="form-control-file input" name="pro_foto" id="pro_foto">
                    <p style="font-size: 75%; text-align: end;">Não precisa selecionar (Permanece a atual)</p>
                    <br>
                    <input type="hidden" name="pro_cod" value="<?php echo $pro_cod; ?>">
                    <input type="hidden" name="pro_foto_antiga" value="<?php echo $pro_foto_antiga; ?>">
                    <button type="submit" class="btn btn-primary btn-login" data-toggle="modal" data-target="#modalExemplo">Confirmar alterações</button> <!--botao p cad-->
                </div>
            </form>
            <a  href="../back-end/visuestoque.php"><i class='bx bx-left-arrow-alt' style="font-size: 30px; color: #158451; font-weight: 700;"></i></a>
        </div>
        <br>

        <!-- Modal -->
        <div class="modal fade" id="modalExemplo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Cadastro Realizado com Sucesso</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-secondary-alt">Confirmar</button>
                </div>
            </div>
            </div>
        </div>
    </section>


    <!--FOOTER-->
    <footer id="footer">
        <div class="footer-content">
            <div class="footer-content-quicklinks">
                <h5>Acesso Rápido</h5>
                <ul>
                    <li class="quicklinks"><a href="#">Início</a></li>
                    <li class="quicklinks"><a href="#sobre">Sobre</a></li>
                    <li class="quicklinks"><a href="#produtos">Produtos</a></li>
                </ul>
            </div>
            <div class="footer-content-contact">
                <h5>Contatos</h5>
                <p>(18) 3222-8466</p>
                <p>(18) 98196-1025</p>
                <p>etecppagricola@gmail.com</p>
                <p>SP-270, 561 - Pres. Prudente - SP</p>
            </div>
            <div class="footer-content-socials">
                <h5>Redes Sociais</h5>
                <a href="https://www.instagram.com/colegioagricolaprudenteoficial/"><i class='bx bxl-instagram'></i>
                    Instagram</a><br>
                <a href="https://www.facebook.com/colegioagricolaprudenteoficial/?locale=pt_BR"><i
                        class='bx bxl-facebook'></i> Facebook</a> <br>
                <a href="https://web.whatsapp.com/send?phone=5518981961025"><i class='bx bxl-whatsapp'></i> WhatsApp</a>
            </div>
        </div>
        <br>
        <p>&copy; 2024
    </footer>

    <!-- JS Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>

        <!--JS do popover-->
        <script>
            $(document).ready(function () {
                $('[data-toggle="popover"]').popover();
            });

            $(document).ready(function () {
                $('[data-toggle="popover"]').popover({
                    trigger: 'manual',
                    delay: { "show": 500, "hide": 2000 }
                }).on("mouseenter", function () {
                    var _this = this;
                    $(this).popover("show");
                    $(".popover").on("mouseleave", function () {
                        $(_this).popover('hide');
                    });
                }).on("mouseleave", function () {
                    var _this = this;
                    setTimeout(function () {
                        if (!$(".popover:hover").length) {
                            $(_this).popover("hide");
                        }
                    }, 200);
                });
            });
        </script>
    </body>
</html>