<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cooperativa | Etec 032</title>
    <!--ICON-->
    <link rel="shortcut icon" type="imagex/png" href="../img/logo ico.ico">
    <!--FONTES-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Acme&family=Cabin:ital,wght@0,400..700;1,400..700&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap"
        rel="stylesheet">
    <!--CSS Do BootStrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--CSS externo-->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/reservas.css">
    <link rel="stylesheet" href="../css/carrinho.css">


    <!--CSS BOX ICONS-->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        #footer {
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            padding-top: 20px;
            background-color: #158451;
            color: #ffffff;
            font-size: 18px;
        }
    </style>
</head>

<body>
    <!--navbar-->
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#" onclick="location.reload();">
            <img src="../img/widelogo.png" width="180" height="60" class="d-inline-block align-top" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
            aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Alterna navegação">
            <span class="navbar-toggler-icon"></span>
        </button>

        <ul class="navbar-nav" style="margin-left: 20px;">
            <div class="collapse navbar-collapse nav-item justify-content-end">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../back-end/visuestoque.php">Estoque</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="relatorios.html">Relatórios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_funcionarios.php">Funcionários</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="fun_reservas.php">Reservas</a>
                    </li>
                </ul>
            </div>
        </ul>

        <div class="collapse navbar-collapse nav-item justify-content-end" id="conteudoNavbarSuportado">
            <!--pesquisar btn-->
            <form class="form-inline my-2 my-lg-0" action="../back-end/pesquisa_estoque.php" method="GET">
                <input class="form-control mr-sm-2" type="search" name="q" placeholder="Pesquisar"
                    aria-label="Pesquisar">
                <button class="btn btn-outline my-2 my-sm-0" type="submit"><i class='bx bx-search'></i></button>
            </form>
            <!--itens-->
            <ul class="navbar-nav">
                <div class="collapse navbar-collapse nav-item justify-content-end">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <div class="dropdown">
                                <a class="nav-link" href="" id="dropdown-perfil" data-toggle="dropdown"><i
                                        class='bx bx-user-circle'></i></a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-perfil">
                                    <a class="dropdown-item" href="perfil_funcionario.php">Perfil</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="#" data-toggle='modal'
                                        data-target='#modalsair'>Sair</a>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </ul>
        </div>
    </nav>

    <!--perfil-->
    <section id="perfil">
        <br>
        <div class="voltar">
            <a href="../back-end/visuestoque.php"><i class='bx bx-left-arrow-alt'
                    style="font-size: 35px; color: #158451; font-weight: 700;"></i></a>
        </div>
        <br>
        <br>

        <div class="content-geral">
            <div class="reservas">
                <h2>Reservas</h2>
                <form method="GET" action="fun_reservas.php" class="form-inline">
                    <label for="status" class="mr-2">Filtrar por status:</label>
                    <select name="status" id="status" class="form-control mr-2">
                        <option value="">Todos</option>
                        <option value="Pendente">Pendentes</option>
                        <option value="Retirada">Retiradas</option>
                        <option value="Cancelada">Canceladas</option>
                    </select>
                    <button type="submit" class="btn btn-primary btn-reservas">Filtrar</button>
                </form>
                <hr style="size: 5;">
                <div class="reservas-grupo">

                    <?php

                    ini_set('default_charset', 'UTF-8');
                    require '../conexao.php';
                    mysqli_set_charset($con, 'utf8');

                    $status = isset($_GET['status']) ? $_GET['status'] : "";

                    // Construir a consulta com base no status
                    $sql = "SELECT c.cli_nome, r.resv_cod, r.resv_status, r.resv_total, r.resv_data, r.resv_tipo FROM Reservas r JOIN Clientes c ON r.cli_email = c.cli_email";

                    if ($status) {
                        // Adicionar condição de status caso tenha sido selecionado
                        $sql .= " WHERE r.resv_status = '$status'";
                    }

                    $sql .= " ORDER BY r.resv_data DESC";

                    $result = mysqli_query($con, $sql);


                    while ($dados = mysqli_fetch_assoc($result)) {
                        $cli_nome = $dados['cli_nome'];
                        $resv_cod = $dados['resv_cod'];
                        $resv_status = $dados['resv_status'];
                        $resv_total = $dados['resv_total'];
                        $resv_data = $dados['resv_data'];
                        $resv_tipo = $dados['resv_tipo'];

                        echo "<div class='reservas-card'>
                        <div class='reservas-card-left'>
                            <h4>Reserva do <span class='trace'> $cli_nome</span></h4>                            
                        </div>
                        <div class='reservas-card-info'>
                            <div class='reservas-card-left'>
                                <div class='reservas-info'>";

                        if ($resv_status ==  "Pendente") {
                            echo "<h5><b>Status:</b> <span class='text-warning'> $resv_status </span></h5>";
                        } else
                            if ($resv_status ==  "Cancelada"){
                                echo "<h5><b>Status:</b> <s><span class='text-danger'> $resv_status </span></s></h5>";
                            }
                            else {
                                echo "<h5><b>Status:</b> <span class='trace'> $resv_status </span></h5>";
                            }

                        echo "<h5><b>Total:</b> <span class='trace'>$resv_total</span></h5>
                                    <!-- Elementos ocultos inicialmente -->
                                    <div class='reservas-extra'>
                                        <h5><b>Data de retirada:</b> <span class='trace'>$resv_data</span></h5>
                                        <h5><b>Pagamneto:</b> <span class='trace'>$resv_tipo</span></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='reservas-card-right'>
                            <a href='produtos_reserva.php?resv_cod=$resv_cod'><button type='button' class='btn btn-primary-alt btn-reservas' >Produtos</button></a>";
                        if ($resv_status ==  "Pendente") {
                            echo "<a href='../back-end/resv_retirada.php?resv_cod=$resv_cod'><button type='button' class='btn btn-primary btn-reservas'>Retirada</button></a>";
                            echo "<div class='reservas-extra-btn'><a href='../back-end/resv_cancelada.php?resv_cod=$resv_cod'><button type='button'  style='width: 80px;' class='btn btn-danger btn-reservas'>Cancelar</button></a></div>";
                        }
                        echo "
                        </div>
                    </div>";
                    }
                    ?>


                </div>
            </div>

        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
    </section>

    <!--FOOTER-->
    <footer id="footer">
        <div class="footer-content">
            <div class="footer-content-contact">
                <h5>Contatos</h5>
                <p>(18) 3222-8466</p>
                <p>(18) 98196-1025</p>
                <p>etecppagricola@gmail.com</p>
                <p>SP-270, 561 - Pres. Prudente - SP</p>
            </div>
            <div class="footer-content-socials">
                <h5>Redes Sociais</h5>
                <a href="https://www.instagram.com/colegioagricolaprudenteoficial/"><i class='bx bxl-instagram'></i>
                    Instagram</a><br>
                <a href="https://www.facebook.com/colegioagricolaprudenteoficial/?locale=pt_BR"><i
                        class='bx bxl-facebook'></i> Facebook</a> <br>
                <a href="https://web.whatsapp.com/send?phone=5518981961025"><i class='bx bxl-whatsapp'></i> WhatsApp</a>
            </div>
        </div>
        <br>
        <p>&copy; 2024
    </footer>


    <!--MODAL - Sair-->
    <div class="modal fade" id="modalsair" tabindex="-1" role="dialog" aria-labelledby="modalsair" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="modalsair">Sair</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h3>Deseja realmente sair?</h3>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <form action="../back-end/sair.php" method="post" style="display: inline;">
                        <input type="hidden" id="pro_cod" name="pro_cod" value="">
                        <button type="submit" class="btn btn-danger">Confirmar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- JS Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>

    <!--JS do popover-->
    <script>
        $(document).ready(function() {
            $('[data-toggle="popover"]').popover();
        });

        $(document).ready(function() {
            $('[data-toggle="popover"]').popover({
                trigger: 'manual',
                delay: {
                    "show": 500,
                    "hide": 2000
                }
            }).on("mouseenter", function() {
                var _this = this;
                $(this).popover("show");
                $(".popover").on("mouseleave", function() {
                    $(_this).popover('hide');
                });
            }).on("mouseleave", function() {
                var _this = this;
                setTimeout(function() {
                    if (!$(".popover:hover").length) {
                        $(_this).popover("hide");
                    }
                }, 200);
            });
        });
    </script>
</body>

</html>