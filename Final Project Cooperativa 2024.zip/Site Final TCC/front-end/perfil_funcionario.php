<?php session_start();?>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cooperativa | Etec 032</title>
    <!--ICON-->
    <link rel="shortcut icon" type="imagex/png" href="img/logo ico.ico">
    <!--FONTES-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Acme&family=Cabin:ital,wght@0,400..700;1,400..700&family=Josefin+Sans:ital,wght@0,100..700;1,100..700&display=swap"
        rel="stylesheet">
    <!--CSS Do BootStrap-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!--CSS externo-->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/perfil.css">
    <link rel="stylesheet" href="../css/login.css">
    

    <!--CSS BOX ICONS-->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <style>
        #footer {
            position: relative;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            padding-top: 20px;
            background-color: #158451;
            color: #ffffff;
            font-size: 18px;
        }
    </style>
</head>

<body>
    <!--navbar-->
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#" onclick="location.reload();">
            <img src="../img/widelogo.png" width="180" height="60" class="d-inline-block align-top" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
            aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Alterna navegação">
            <span class="navbar-toggler-icon"></span>
        </button>

        <ul class="navbar-nav" style="margin-left: 20px;">
            <div class="collapse navbar-collapse nav-item justify-content-end">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../back-end/visuestoque.php">Estoque</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="relatorios.html">Relatórios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="lista_funcionarios.php">Funcionários</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="fun_reservas.php">Reservas</a>
                    </li>
                </ul>
            </div>
        </ul>

        <div class="collapse navbar-collapse nav-item justify-content-end" id="conteudoNavbarSuportado">
            <!--pesquisar btn-->
            <form class="form-inline my-2 my-lg-0" action="../back-end/pesquisa_estoque.php" method="GET">
                <input class="form-control mr-sm-2" type="search" name="q" placeholder="Pesquisar"
                    aria-label="Pesquisar">
                <button class="btn btn-outline my-2 my-sm-0" type="submit"><i class='bx bx-search'></i></button>
            </form>
            <!--itens-->
            <ul class="navbar-nav">
                <div class="collapse navbar-collapse nav-item justify-content-end">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                        <div class="dropdown">
                                <a class="nav-link" href="" id="dropdown-perfil" data-toggle="dropdown"><i class='bx bx-user-circle'></i></a>
                                
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-perfil">
                                    <a class="dropdown-item" href="perfil_funcionario.php">Perfil</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="#" data-toggle='modal' data-target='#modalsair'>Sair</a>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
        </div>
    </nav>
    <?php
    
    
    ini_set('default_charset', 'UTF-8');
    require '../conexao.php';

    $log_email = $_SESSION['log_email'];

    $sql = "select * from Funcionarios where fun_email='$log_email'";

    $result = mysqli_query($con, $sql);
    $dados = mysqli_fetch_assoc($result);

    $fun_nome = $dados['fun_nome'];
    $fun_telefone = $dados['fun_telefone'];
    $fun_email = $dados['fun_email'];
    $fun_senha = $dados['fun_senha'];

    ?>

    <!--perfil-->
    <section id="perfil">
        <H1 style="color: white;"><span class="trace">|</span>Seu perfil</H1>
        <br>
        <div class="voltar">
            <a href="produtos.html"><i class='bx bx-left-arrow-alt'
                    style="font-size: 35px; color: #158451; font-weight: 700;"></i></a>
        </div>

        <div class="content-geral">
            <div class="config">
                <?php

                echo "
                <h2><span class='trace'>Configurações</span> da Conta</h2>
                <hr style='size: 5;'>

                <div class='config-info'>
                    <div class='config-info-left'>
                        <b>
                            <p>Nome</p>
                            <p>E-mail</p>
                            <p>Telefone</p>
                        </b>
                    </div>
                    <div class='config-info-right'> <!-- ALTERAR AS INFORMAÇÕES AQ EDUARDO-->
                        <p>$fun_nome</p>
                        <p>$fun_email</p>
                        <p>$fun_telefone</p>
                    </div>
                </div>";
                
                ?>
                <button type='button' class='btn btn-primary-alt' data-toggle='modal' data-target='#modaldelete' onclick='setDeleteCode($fun_email)'>Excluir conta</button>
                
            </div>


            <div class="config">
                <h2>Alterar <span class="trace">Dados</span></h2>
                <hr style="width: 400;">
                <form class="form-login" action="../back-end/alterar_funcionario.php" method="POST">
                    <div class="form-group-login">
                    <label for="email">E-mail</label> <!--email-->
                    <input type="text" id="alter_fun_email" class="input" name="alter_fun_email" placeholder="Digite seu e-mail" required="" value="<?php echo $fun_email?>">
                    <label for="nome">Nome</label> <!--nome-->
                    <input type="text" id="fun_nome" class="input" name="fun_nome" placeholder="Digite seu nome completo" required="" value="<?php echo $fun_nome?>">
                    <label for="tel">Telefone</label> <!--telefone-->
                    <input type="tel" id="fun_telefone" class="input" name="fun_telefone" placeholder="(00) 00000-0000" maxlength="15" onkeyup="handlePhone(event)" required="" value="<?php echo $fun_telefone?>">
                    <label for="senha">Nova Senha</label> <!--senha-->
                    <input type="password" id="nova_senha" class="input" name="nova_fun_senha" placeholder="Se quiser alterar *(não obrigatório)" maxlength="10" >
                    <p style="font-size: 75%; text-align: end;">Apenas 10 dígitos</p>
                    <input type="hidden" id="senha" class="input" name="fun_senha"  required="" value="<?php echo $fun_senha?>">
                        <br>
                        <button type="submit" class="btn btn-primary btn-login">Alterar</button> <!--botao p entra-->
                        
                    </div>
                </form>
            </div>
        </div>
        <br>
        <br>
        <br>
    </section>
    

    <!--FOOTER-->
    <footer id="footer">
        <div class="footer-content">
            <div class="footer-content-quicklinks">
                <h5>Acesso Rápido</h5>
                <ul>
                    <li class="quicklinks"><a href="index.html">Início</a></li>
                    <li class="quicklinks"><a href="index.html">Sobre</a></li>
                    <li class="quicklinks"><a href="#produtos">Produtos</a></li>
                </ul>
            </div>
            <div class="footer-content-contact">
                <h5>Contatos</h5>
                <p>(18) 3222-8466</p>
                <p>(18) 98196-1025</p>
                <p>etecppagricola@gmail.com</p>
                <p>SP-270, 561 - Pres. Prudente - SP</p>
            </div>
            <div class="footer-content-socials">
                <h5>Redes Sociais</h5>
                <a href="https://www.instagram.com/colegioagricolaprudenteoficial/"><i class='bx bxl-instagram'></i>
                    Instagram</a><br>
                <a href="https://www.facebook.com/colegioagricolaprudenteoficial/?locale=pt_BR"><i
                        class='bx bxl-facebook'></i> Facebook</a> <br>
                <a href="https://web.whatsapp.com/send?phone=5518981961025"><i class='bx bxl-whatsapp'></i> WhatsApp</a>
            </div>
        </div>
        <br>
        <p>&copy; 2024
    </footer>
    

    <!--MODAL-->
    <div class="modal fade" id="modaldelete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="exampleModalLabel">Excluir Conta</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h3>Tem certeza que deseja excluir esta conta?</h3>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <form action="../back-end/excluir_conta_funcionario.php" method="post" style="display: inline;">
                    <input type="hidden" name="fun_email" value="<?php echo $fun_email; ?>">
                        <button type="submit" class="btn btn-danger">Confirmar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!--MODAL - Sair-->
    <div class="modal fade" id="modalsair" tabindex="-1" role="dialog" aria-labelledby="modalsair" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="modalsair">Sair</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h3>Deseja realmente sair?</h3>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <form action="../back-end/sair.php" method="post" style="display: inline;">
                        <input type="hidden" id="pro_cod" name="pro_cod" value="">
                        <button type="submit" class="btn btn-danger">Confirmar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- JS Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>

    <!--JS do popover-->
    <script>
        const handlePhone = (event) => {
            let input = event.target
            input.value = phoneMask(input.value)
        }

        const phoneMask = (value) => {
            if (!value) return ""
            value = value.replace(/\D/g, '')
            value = value.replace(/(\d{2})(\d)/, "($1) $2")
            value = value.replace(/(\d)(\d{4})$/, "$1-$2")
            return value
        }

        $(document).ready(function () {
            $('[data-toggle="popover"]').popover();
        });

        $(document).ready(function () {
            $('[data-toggle="popover"]').popover({
                trigger: 'manual',
                delay: { "show": 500, "hide": 2000 }
            }).on("mouseenter", function () {
                var _this = this;
                $(this).popover("show");
                $(".popover").on("mouseleave", function () {
                    $(_this).popover('hide');
                });
            }).on("mouseleave", function () {
                var _this = this;
                setTimeout(function () {
                    if (!$(".popover:hover").length) {
                        $(_this).popover("hide");
                    }
                }, 200);
            });
        });
    </script>


</body>

</html>