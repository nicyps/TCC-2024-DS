<?php
    ini_set('default_charset','UTF-8');

    $servidor = 'localhost';
    $usuario = 'root';
    $senha = '';
    $banco = 'cooperativa';
    $con=mysqli_connect($servidor, $usuario, $senha, $banco);
?>